<?php
include("../connectDB.php");
date_default_timezone_set('America/Bogota');

//Error Handler

function divError(){
 echo "";
}
set_error_handler("divError");


$localzone = new DateTime('now');
$localtime= $localzone->format('H:i:s');
$localdate= $localzone->format('Y-m-d');

$mxzone = new DateTimeZone('America/Mexico_City');
$localzone->setTimezone($mxzone);
$mxtime= $localzone->format('H:i:s');
$mxdate= $localzone->format('Y-m-d');

$query="SELECT
			Canal,
			SUM(Monto) as Monto,
			SUM(Venta) as Venta,
			SUM(Xld) as Xld
		FROM
			(
				SELECT
		     		a.Fecha, a.asesor, Afiliado, a.Localizador, SUM(VentaMXN+OtrosIngresosMXN+EgresosMXN) as Monto, SUM(VentaMXN) as VentaMXN,
		     		SUM(VentaMXN+OtrosIngresosMXN) as Venta,
		     		SUM(EgresosMXN) as Xld,
		     	   `id Departamento` as PCRC, `N Corto`, Dolar, New_Loc,
		     	   CASE 
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND Afiliado NOT LIKE '%outlet%' AND Afiliado NOT LIKE '%me.pricetravel%' AND (((Afiliado LIKE'%pricetravel.com.mx%' OR Afiliado LIKE'%Cerrados%') AND (`id Departamento` NOT IN (28,29,30,31,5) AND `id Departamento` IS NOT NULL)))) THEN 'ibMPCC'
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND Afiliado LIKE'%agentes.pricetravel.com.mx%' AND (`id Departamento` IN (29,30,31) OR `id Departamento` IS NULL)) THEN 'ibMPPDV'
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND (Afiliado NOT LIKE'%pricetravel.com.mx%' AND Afiliado NOT LIKE'%Cerrados%') AND (`id Departamento` IN (3,35,4,6,9,43))) THEN 'ibMT'
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND (`id Departamento`=5)) THEN 'usCC'
     	   	WHEN (New_Loc IS NOT NULL) THEN 'usPDV'
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND Afiliado LIKE'%shop.pricetravel.com.mx%') THEN 'PDV'
     	   	WHEN (a.asesor=-1 AND New_Loc IS NULL) THEN 'ol'
     	   	WHEN (a.asesor=-100) THEN 'rb'
     	   	WHEN (Afiliado LIKE'%shop.pricetravel.co') THEN 'PDVCO'
				ELSE 'Otro'
					END as Canal 
		     	FROM
		     		d_Locs a
		     	LEFT JOIN
		     		Asesores b
		     	ON
		     		a.asesor=b.id
		     	LEFT JOIN
		     		Fechas c
		     	ON
		     		a.Fecha=c.Fecha
		     	LEFT JOIN
		     		pdv_registro_llamadas d
		     	ON
		     		a.Localizador=d.New_Loc AND
		     		a.Fecha=CAST(d.Last_Update as DATE)
		     	WHERE
		     		a.Fecha=CURDATE()
		     	GROUP BY
		     		a.Localizador
			) locs
		GROUP BY 
			Canal";
if ($today_info=$connectdb->query($query)) {
   while ($fila = $today_info->fetch_assoc()) {
   		//Monto
   		$td[$fila['Canal']]['monto']['Td']=$fila['Monto'];
	    $td[$fila['Canal']]['venta']['Td']=$fila['Venta'];
		$td[$fila['Canal']]['xld']['Td']=$fila['Xld'];
	}
}else{
	echo $connectdb->error."<br> ON <br>$query<br>";
}

//Faltantes
$td['us']['monto']['Td']=$td['usCC']['monto']['Td']+$td['usPDV']['monto']['Td'];
$td['us']['venta']['Td']=$td['usCC']['venta']['Td']+$td['usPDV']['venta']['Td'];
$td['us']['xld']['Td']=$td['usCC']['xld']['Td']+$td['usPDV']['xld']['Td'];

$td['ibMP']['monto']['Td']=$td['ibMPPDV']['monto']['Td']+$td['ibMPCC']['monto']['Td'];
$td['ibMP']['venta']['Td']=$td['ibMPPDV']['venta']['Td']+$td['ibMPCC']['venta']['Td'];
$td['ibMP']['xld']['Td']=$td['ibMPPDV']['xld']['Td']+$td['ibMPCC']['xld']['Td'];

$query="SELECT
        	Canal,
        	COUNT(Localizador) as Locs
        FROM
        	(SELECT
        		a.Fecha, a.asesor, Afiliado, a.Localizador, SUM(Venta+OtrosIngresos+Egresos) as Monto, SUM(Venta) as Venta,
        	   `id Departamento` as PCRC, `N Corto`, Dolar, New_Loc,
		     	   CASE 
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND Afiliado NOT LIKE '%outlet%' AND Afiliado NOT LIKE '%me.pricetravel%' AND (((Afiliado LIKE'%pricetravel.com.mx%' OR Afiliado LIKE'%Cerrados%') AND (`id Departamento` NOT IN (28,29,30,31,5) AND `id Departamento` IS NOT NULL)))) THEN 'ibMPCC'
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND Afiliado LIKE'%agentes.pricetravel.com.mx%' AND (`id Departamento` IN (29,30,31) OR `id Departamento` IS NULL)) THEN 'ibMPPDV'
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND (Afiliado NOT LIKE'%pricetravel.com.mx%' AND Afiliado NOT LIKE'%Cerrados%') AND (`id Departamento` IN (3,35,4,6,9,43))) THEN 'ibMT'
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND (`id Departamento`=5)) THEN 'usCC'
     	   	WHEN (New_Loc IS NOT NULL) THEN 'usPDV'
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND Afiliado LIKE'%shop.pricetravel.com.mx%') THEN 'PDV'
     	   	WHEN (a.asesor=-1 AND New_Loc IS NULL) THEN 'ol'
     	   	WHEN (a.asesor=-100) THEN 'rb'
     	   	WHEN (Afiliado LIKE'%shop.pricetravel.co') THEN 'PDVCO'
				ELSE 'Otro'
					END as Canal 
        	FROM
        		d_Locs a
        	LEFT JOIN
        		Asesores b
        	ON
        		a.asesor=b.id
        	LEFT JOIN
        		Fechas c
        	ON
        		a.Fecha=c.Fecha
        	LEFT JOIN
        		pdv_registro_llamadas d
        	ON
        		a.Localizador=d.New_Loc AND
        		a.Fecha=CAST(d.Last_Update as DATE)
        	WHERE
        		a.Fecha='".date('Y-m-d')."'
        	GROUP BY
        		a.Localizador
        	HAVING
        		Venta>0 AND Monto>0) locs
        	GROUP BY
        		Canal

        ";
        
if ($today_locs=$connectdb->query($query)) {
   while ($fila = $today_locs->fetch_assoc()) {
		$td[$fila['Canal']]['loc']['Td']=$fila['Locs'];
	}
}else{
	echo $connectdb->error."<br> ON <br>$query<br>";
}

$td['us']['loc']['Td']=$td['usCC']['loc']['Td']+$td['usPDV']['loc']['Td'];
$td['ibMP']['loc']['Td']=$td['ibMPCC']['loc']['Td']+$td['ibMPPDV']['loc']['Td'];

$query="SELECT
				locs.Fecha,
				Canal,
				CASE
					WHEN (Canal='ibMPCC' OR Canal='ibMPPDV') THEN LlamadasMP
					WHEN Canal='ibMT' THEN LlamadasIT
					ELSE NULL
				END as Llamadas,
				SUM(Monto) as Monto
		 FROM
			(SELECT
				a.Fecha, a.asesor, Afiliado, a.Localizador, SUM(VentaMXN+OtrosIngresosMXN+EgresosMXN) as Monto, SUM(VentaMXN) as VentaMXN,
				`id Departamento` as PCRC, `N Corto`, Dolar, New_Loc,
		     	   CASE 
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND Afiliado NOT LIKE '%outlet%' AND Afiliado NOT LIKE '%me.pricetravel%' AND (((Afiliado LIKE'%pricetravel.com.mx%' OR Afiliado LIKE'%Cerrados%') AND (`id Departamento` NOT IN (28,29,30,31,5) AND `id Departamento` IS NOT NULL)))) THEN 'ibMPCC'
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND Afiliado LIKE'%agentes.pricetravel.com.mx%' AND (`id Departamento` IN (29,30,31) OR `id Departamento` IS NULL)) THEN 'ibMPPDV'
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND (Afiliado NOT LIKE'%pricetravel.com.mx%' AND Afiliado NOT LIKE'%Cerrados%') AND (`id Departamento` IN (3,35,4,6,9,43))) THEN 'ibMT'
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND (`id Departamento`=5)) THEN 'usCC'
     	   	WHEN (New_Loc IS NOT NULL) THEN 'usPDV'
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND Afiliado LIKE'%shop.pricetravel.com.mx%') THEN 'PDV'
     	   	WHEN (a.asesor=-1 AND New_Loc IS NULL) THEN 'ol'
     	   	WHEN (a.asesor=-100) THEN 'rb'
     	   	WHEN (Afiliado LIKE'%shop.pricetravel.co') THEN 'PDVCO'
				ELSE 'Otro'
					END as Canal 
			FROM
				t_Locs a
				LEFT JOIN
				Asesores b
				ON a.asesor=b.id
				LEFT JOIN
				Fechas c
				ON a.Fecha=c.Fecha
			LEFT JOIN
	    		pdv_registro_llamadas d
	    	ON
	    		a.Localizador=d.New_Loc AND
	    		a.Fecha=CAST(d.Last_Update as DATE)
		WHERE
			(a.Fecha='".date('Y-m-d',strtotime('-1 days'))."' OR
			a.Fecha='".date('Y-m-d',strtotime('-7 days'))."') AND
			Hora<='$mxtime'
		GROUP BY
			a.Localizador
		) locs
	    LEFT JOIN
			(
				SELECT
					d.Fecha,
					COUNT(IF(Skill=3,ac_id,NULL)) as LlamadasAll,
					COUNT(IF(Skill=35,ac_id,NULL)) as LlamadasMP,
					COUNT(IF(Skill=3,ac_id,NULL)) as LlamadasIT,
					COUNT(IF(Skill=3 AND Canal='COPA',ac_id,NULL)) as LlamadasCOPA,
					COUNT(IF(Skill=3 AND Canal='COOMEVA',ac_id,NULL)) as LlamadasCOOMEVA
				FROM
					Fechas d
				JOIN
					t_Answered_Calls a
				ON
					d.Fecha=a.Fecha
				LEFT JOIN
					Cola_Skill b
				ON
					a.Cola=b.Cola
				LEFT JOIN
					Dids c
				ON
					a.DNIS=c.DID
				WHERE
					(a.Fecha='".date('Y-m-d',strtotime('-1 days'))."' OR
	        		a.Fecha='".date('Y-m-d',strtotime('-7 days'))."') AND
	        		Hora<='$mxtime'
				GROUP BY
					a.Fecha
			) Calls
		ON
			locs.Fecha=Calls.Fecha
		GROUP BY
			Fecha, Canal



        ";
        
if ($lw_y_info=$connectdb->query($query)) {
   while ($fila = $lw_y_info->fetch_assoc()) {
			
		if($fila['Fecha']==date('Y-m-d',strtotime('-1 days'))){$fechaarray="Y";}else{$fechaarray="LW";}
	    
	    $td[$fila['Canal']]['monto'][$fechaarray]=$fila['Monto'];
	    $td[$fila['Canal']]['callstotal'][$fechaarray]=$fila['Llamadas'];
	}
}else{
	echo $lw_y_info->error."<br> ON <br>$query<br>";
}

$td['us']['monto']['Y']=$td['usCC']['monto']['Y']+$td['usPDV']['monto']['Y'];
$td['ibMP']['monto']['Y']=$td['ibMPCC']['monto']['Y']+$td['ibMPPDV']['monto']['Y'];
$td['ibMP']['callstotal']['Y']=$td['ibMPCC']['callstotal']['Y'];

$td['us']['monto']['LW']=$td['usCC']['monto']['LW']+$td['usPDV']['monto']['LW'];
$td['ibMP']['monto']['LW']=$td['ibMPCC']['monto']['LW']+$td['ibMPPDV']['monto']['LW'];
$td['ibMP']['callstotal']['LW']=$td['ibMPCC']['callstotal']['LW'];
$td['ibMPTEST']['callstotal']['LW']=$td['ibMPCC']['callstotal']['LW'];

$query="SELECT
			Canal,
			locs.Fecha,
			COUNT(Localizador) as Locs
	 FROM
		(SELECT
			a.Fecha, a.asesor, Afiliado, a.Localizador, SUM(VentaMXN+OtrosIngresosMXN+EgresosMXN) as Monto, SUM(VentaMXN) as VentaMXN,
			`id Departamento` as PCRC, `N Corto`, Dolar, New_Loc,
		     	   CASE 
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND Afiliado NOT LIKE '%outlet%' AND Afiliado NOT LIKE '%me.pricetravel%' AND (((Afiliado LIKE'%pricetravel.com.mx%' OR Afiliado LIKE'%Cerrados%') AND (`id Departamento` NOT IN (28,29,30,31,5) AND `id Departamento` IS NOT NULL)))) THEN 'ibMPCC'
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND Afiliado LIKE'%agentes.pricetravel.com.mx%' AND (`id Departamento` IN (29,30,31) OR `id Departamento` IS NULL)) THEN 'ibMPPDV'
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND (Afiliado NOT LIKE'%pricetravel.com.mx%' AND Afiliado NOT LIKE'%Cerrados%') AND (`id Departamento` IN (3,35,4,6,9,43))) THEN 'ibMT'
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND (`id Departamento`=5)) THEN 'usCC'
     	   	WHEN (New_Loc IS NOT NULL) THEN 'usPDV'
     	   	WHEN (a.asesor NOT IN (-1,-100)  AND New_Loc IS NULL AND Afiliado LIKE'%shop.pricetravel.com.mx%') THEN 'PDV'
     	   	WHEN (a.asesor=-1 AND New_Loc IS NULL) THEN 'ol'
     	   	WHEN (a.asesor=-100) THEN 'rb'
     	   	WHEN (Afiliado LIKE'%shop.pricetravel.co') THEN 'PDVCO'
				ELSE 'Otro'
					END as Canal 
		FROM
			t_Locs a
		LEFT JOIN
			Asesores b
		ON
			a.asesor=b.id
		LEFT JOIN
			Fechas c
		ON a.Fecha=c.Fecha
		LEFT JOIN
    		pdv_registro_llamadas d
    	ON
    		a.Localizador=d.New_Loc AND
    		a.Fecha=CAST(d.Last_Update as DATE)
    	WHERE
			(a.Fecha='".date('Y-m-d',strtotime('-1 days'))."' OR
			a.Fecha='".date('Y-m-d',strtotime('-7 days'))."') AND
			Hora<='$mxtime'
		GROUP BY
			a.Localizador
		HAVING
	        		VentaMXN>0 AND Monto>0
	        	) locs
	    GROUP BY
			Fecha, Canal";
			
if ($lw_y_loc=$connectdb->query($query)) {
   while ($fila = $lw_y_loc->fetch_assoc()) {
			
		if($fila['Fecha']==date('Y-m-d',strtotime('-1 days'))){$fechaarray="Y";}else{$fechaarray="LW";}
	    
	    $td[$fila['Canal']]['loc'][$fechaarray]=$fila['Locs'];
	}
}else{
	echo $connectdb->error."<br> ON <br>$query<br>";
}

$td['us']['loc']['LW']=$td['usCC']['loc']['LW']+$td['usPDV']['loc']['LW'];
$td['ibMP']['loc']['LW']=$td['ibMPCC']['loc']['LW']+$td['ibMPPDV']['loc']['LW'];

$td['us']['loc']['Y']=$td['usCC']['loc']['Y']+$td['usPDV']['loc']['Y'];
$td['ibMP']['loc']['Y']=$td['ibMPCC']['loc']['Y']+$td['ibMPPDV']['loc']['Y'];



//Calls TD
$query="SELECT SUM(Calls) as Calls, SUM(Unanswered) as Unanswered, Skill FROM d_dids_calls WHERE Fecha=CURDATE() GROUP BY Skill";

if ($calls_td=$connectdb->query($query)) {
   while ($fila = $calls_td->fetch_assoc()) {
		switch($fila['Skill']){
			case 35:
				$dept_calls='pin';
				$td['ibMP']['calls']['Td']=intval($fila['Calls']);
	            if($fila['Unanswered']==""){
	                $td['ibMP']['uncalls']['Td']=intval(0);
					$td['ibMP']['callstotal']['Td']=intval($fila['Calls']);
	            }else{
	                $td['ibMP']['uncalls']['Td']=intval($fila['Unanswered']);
					$td['ibMP']['callstotal']['Td']=intval($fila['Calls'])+intval($fila['Unanswered']);
	            }
	
				break;
			case 3:
				$dept_calls='it';
				$td['ibMT']['calls']['Td']=intval($fila['Calls']);
				if($fila['Unanswered']==""){
	                $td['ibMT']['uncalls']['Td']=intval(0);
					$td['ibMT']['callstotal']['Td']=intval($fila['Calls']);
	            }else{
	                $td['ibMT']['uncalls']['Td']=intval($fila['Unanswered']);
	                $td['ibMT']['callstotal']['Td']=intval($fila['Calls'])+intval($fila['Unanswered']);
	            }
				break;
			default:
				break;
		}
	}
}else{
	echo $connectdb->error."<br> ON <br>$query<br>";
}

//LastUpdate

$query="SELECT MAX(Last_Update) as Last FROM d_Locs";
if ($last_UD=$connectdb->query($query)) {
   while ($fila = $last_UD->fetch_assoc()) {
   		$cun_zone = new DateTimeZone('America/Bogota');
   		$tmp = new DateTime($fila['Last']." America/Mexico_City");
   		$tmp -> setTimezone($cun_zone);
		$td['lu']=$tmp->format('Y-m-d H:i:s');
	}
}else{
	echo $connectdb->error."<br> ON <br>$query<br>";
}

foreach($td as $canal => $info){
		
	switch($canal){
		case 'ibMP':
		case 'ibMT':
			$td[$canal]['fc']['Td']=$info['loc']['Td']/$info['calls']['Td']*100;
			break;
	}
}




print json_encode($td,JSON_PRETTY_PRINT);



?>
