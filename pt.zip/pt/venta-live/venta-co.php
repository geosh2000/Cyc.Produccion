<?php
//header('Location: venta_2.php');
 session_start();
$this_page=$_SERVER['PHP_SELF'];
$iddiv=0;

if($_SESSION['login']!='1'){ include("../common/login.php"); exit;}
include("../common/scripts.php");
$credential='tablas_f';
?>

<style>
.bloque{
    height: 360;
    padding: 10;

}

.bloque_short{
    height: 280;
    padding: 10;

}

.title{
    float: left;
    margin: 0;
    width: 35%;
    height: 100%;
    color: white;
    background: #215086;
    display: flex;
    justify-content: right;
    text-align: right;
    align-items: center;
    font-size:75;
    line-height: normal;
    font-family: Arial, Helvetica, sans-serif;
    font-weight: bold;
    font-style: normal;
    font-smoothing: antialiased;
    -webkit-font-smoothing: antialiased;
    -moz-font-smoothing: antialiased;
    -o-font-smoothing: antialiased;
    -ms-font-smoothing: antialiased;
    text-decoration: none;
    border-radius: 3px #83DDEC;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    -o-border-radius: 3px;
    -ms-border-radius: 3px;
    border: 1px solid rgba(0,0,0,0.50);
    border-top: 1px solid rgba(0,0,0,0.001);
    box-shadow: 0 0 10px rgba(0,0,0,0.35), 0px 1px 3px rgba(0,0,0,0.18), inset 0px -3px 0px rgba(0,0,0,0.35), inset 0px 14px 14px rgba(255,255,255,0.10);
    -webkit-box-shadow: 0 0 10px rgba(0,0,0,0.35), 0px 1px 3px rgba(0,0,0,0.18), inset 0px -3px 0px rgba(0,0,0,0.35), inset 0px 14px 14px rgba(255,255,255,0.10);
    -moz-box-shadow: 0 0 10px rgba(0,0,0,0.35), 0px 1px 3px rgba(0,0,0,0.18), inset 0px -3px 0px rgba(0,0,0,0.35), inset 0px 14px 14px rgba(255,255,255,0.10);
    -o-box-shadow: 0 0 10px rgba(0,0,0,0.35), 0px 1px 3px rgba(0,0,0,0.18), inset 0px -3px 0px rgba(0,0,0,0.35), inset 0px 14px 14px rgba(255,255,255,0.10);
    -ms-box-shadow: 0 0 10px rgba(0,0,0,0.35), 0px 1px 3px rgba(0,0,0,0.18), inset 0px -3px 0px rgba(0,0,0,0.35), inset 0px 14px 14px rgba(255,255,255,0.10);text-decoration: none;
    text-shadow: 1px 1px 2px black, 0 0 5px darkblue;
    padding: 0 15 0 0;


}

.container{
    background: #779ECB;
    height: 100%;
    line-height: 100px;
    color: white;
    display: flex;
    justify-content: left;
    padding-left: 25;
    align-items: center;
    font-size: 75;
    font-family: Arial, Helvetica, sans-serif;
    font-weight: bold;
    font-style: normal;
    font-smoothing: antialiased;
    -webkit-font-smoothing: antialiased;
    -moz-font-smoothing: antialiased;
    -o-font-smoothing: antialiased;
    -ms-font-smoothing: antialiased;
    text-decoration: none;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    -o-border-radius: 3px;
    -ms-border-radius: 3px;
    border: 1px solid rgba(0,0,0,0.50);
    border-top: 1px solid rgba(0,0,0,0.001);
    box-shadow: 0 0 10px rgba(0,0,0,0.35), 0px 1px 3px rgba(0,0,0,0.18), inset 0px -3px 0px rgba(0,0,0,0.35), inset 0px 14px 14px rgba(255,255,255,0.10);
    -webkit-box-shadow: 0 0 10px rgba(0,0,0,0.35), 0px 1px 3px rgba(0,0,0,0.18), inset 0px -3px 0px rgba(0,0,0,0.35), inset 0px 14px 14px rgba(255,255,255,0.10);
    -moz-box-shadow: 0 0 10px rgba(0,0,0,0.35), 0px 1px 3px rgba(0,0,0,0.18), inset 0px -3px 0px rgba(0,0,0,0.35), inset 0px 14px 14px rgba(255,255,255,0.10);
    -o-box-shadow: 0 0 10px rgba(0,0,0,0.35), 0px 1px 3px rgba(0,0,0,0.18), inset 0px -3px 0px rgba(0,0,0,0.35), inset 0px 14px 14px rgba(255,255,255,0.10);
    -ms-box-shadow: 0 0 10px rgba(0,0,0,0.35), 0px 1px 3px rgba(0,0,0,0.18), inset 0px -3px 0px rgba(0,0,0,0.35), inset 0px 14px 14px rgba(255,255,255,0.10);text-decoration: none;
    text-shadow: 1px 1px 2px black, 0 0 25px #215086, 0 0 5px darkblue;

}

.pin{
    background: #AD2E4E;
}

.pus{
    background: #D35A78;
}

.ppdv{
    background: #E292A6;
}

.online{
    background: #efc2cd;
}

.cpin{
    background: #C68B9E;
    text-shadow: 1px 1px 2px black, 0 0 25px #AD2E4E, 0 0 5px darkblue;border-radius: 3px #83DDEC;
}

.cpus{
    background: #DD92A9;
    text-shadow: 1px 1px 2px black, 0 0 25px #AD2E4E, 0 0 5px darkblue;border-radius: 3px #83DDEC;
}

.cppdv{
    background: #E9BECA;
    text-shadow: 1px 1px 2px black, 0 0 25px #AD2E4E, 0 0 5px darkblue;border-radius: 3px #83DDEC;
}

.conline{
    background: #f2d9e0;
    text-shadow: 1px 1px 2px black, 0 0 25px #AD2E4E, 0 0 5px darkblue;border-radius: 3px #83DDEC;
}


.title p{
    background: #C7CC2C;
    vertical-align: middle;
    line-height: normal;
    margin: 10;

}

.upvar{
    color: #08EF08;
}

.downvar{
    color: #FF1100;
}

.container a{
    font-size:25;
    text-align: center;
    line-height: 1;
}

.container p  a aval{
    width: 100px;
}

.zoomout{
    width: 1020;
}

.header{
    background: #215086;
    height: 205;
    margin-bottom: 0px;
    line-height: 100px;
    color: white;
    text-align: center;
    font-size: 75;
    font-family: Arial, Helvetica, sans-serif;
    font-weight: bold;
    font-style: normal;
    font-smoothing: antialiased;
    -webkit-font-smoothing: antialiased;
    -moz-font-smoothing: antialiased;
    -o-font-smoothing: antialiased;
    -ms-font-smoothing: antialiased;
    text-decoration: none;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    -o-border-radius: 3px;
    -ms-border-radius: 3px;
    border: 1px solid rgba(0,0,0,0.50);
    border-top: 1px solid rgba(0,0,0,0.001);
    box-shadow: 0 0 10px rgba(0,0,0,0.35), 0px 1px 3px rgba(0,0,0,0.18), inset 0px -3px 0px rgba(0,0,0,0.35), inset 0px 14px 14px rgba(255,255,255,0.10);
    -webkit-box-shadow: 0 0 10px rgba(0,0,0,0.35), 0px 1px 3px rgba(0,0,0,0.18), inset 0px -3px 0px rgba(0,0,0,0.35), inset 0px 14px 14px rgba(255,255,255,0.10);
    -moz-box-shadow: 0 0 10px rgba(0,0,0,0.35), 0px 1px 3px rgba(0,0,0,0.18), inset 0px -3px 0px rgba(0,0,0,0.35), inset 0px 14px 14px rgba(255,255,255,0.10);
    -o-box-shadow: 0 0 10px rgba(0,0,0,0.35), 0px 1px 3px rgba(0,0,0,0.18), inset 0px -3px 0px rgba(0,0,0,0.35), inset 0px 14px 14px rgba(255,255,255,0.10);
    -ms-box-shadow: 0 0 10px rgba(0,0,0,0.35), 0px 1px 3px rgba(0,0,0,0.18), inset 0px -3px 0px rgba(0,0,0,0.35), inset 0px 14px 14px rgba(255,255,255,0.10);text-decoration: none;
    text-shadow: 1px 1px 2px black, 0 0 25px #215086, 0 0 5px darkblue;
}

</style>
<script>

$(function(){

  sendRequest();

  setInterval(function(){
           sendRequest();
       },60000);
  
  $( 'test' ).tooltip({
		items: "[title]",
		content: function() {
	        var element = $( this );
	        if ( element.is( "[title]" ) ) {
	          var tipo = element.attr('tipo');
	          var camp = element.attr('camp');
	          return showMore(tipo,camp);
	    	}
		}
        
    });
       
  function getVal(data,canal,tipo,date,op,comp,value){
  	var operacion = (typeof op === 'undefined') ? 'total' : op;
  	var compara = (typeof comp === 'undefined' || comp == 0) ? 'Td' : comp;
  	var valor;
  	var datothis = (typeof data[canal][tipo][date] === 'undefined') ? 0 : data[canal][tipo][date];
  	var datocomp = (typeof data[canal][tipo][compara] === 'undefined') ? 0 : data[canal][tipo][compara];
  	var value_ok = (typeof value === 'undefined') ? 0 : value;
  	tipo_cambio=0.0065;
  	
  	switch(operacion){
  		case 'total':
  			valor=datothis;
  			break;
  		case 'var':
  			valor=parseFloat(datothis)/parseFloat(datocomp)*100-100;
  			break
  		case 'av':
  			var datolocs = (typeof data[canal]['loc'][date] === 'undefined') ? 0 : data[canal]['loc'][date];
  			valor=(datothis/tipo_cambio)/datolocs;
  			break
  	}
  	
  	if(value_ok=='valor'){
		return valor;	
	}else{
		switch(tipo){
	  		case 'monto':
	  		case 'venta':
	  		case 'xld':
	  			if(operacion=='var'){
	  				return number_format(valor,2);
	  			}
	  			return number_format(valor/tipo_cambio,2);
	  			break;
	  		case 'fc':
	  			return number_format(valor,2);
	  			break;
	  		default:
	  			if(operacion=='var'){
	  				return number_format(valor,2);
	  			}
	  			return valor;
	  			break; 		
	  		
	  	}	
	}
  	
  		
  }

  function nC(x) {
        return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    
   function number_format (number, decimals, decPoint, thousandsSep) {
   	  var number = (number + '').replace(/[^0-9+\-Ee.]/g, '')
	  var n = !isFinite(+number) ? 0 : +number
	  var prec = !isFinite(+decimals) ? 0 : Math.abs(decimals)
	  var sep = (typeof thousandsSep === 'undefined') ? ',' : thousandsSep
	  var dec = (typeof decPoint === 'undefined') ? '.' : decPoint
	  var s = ''
	
	  var toFixedFix = function (n, prec) {
	    var k = Math.pow(10, prec)
	    return '' + (Math.round(n * k) / k)
	      .toFixed(prec)
	  }
	
	  // @todo: for IE parseFloat(0.55).toFixed(0) = 0;
	  s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.')
	  if (s[0].length > 3) {
	    s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep)
	  }
	  if ((s[1] || '').length < prec) {
	    s[1] = s[1] || ''
	    s[1] += new Array(prec - s[1].length + 1).join('0')
	  }
	
	  return s.join(dec)
	}

   function sendRequest(){
        $.ajax({
            url: "_query_venta_v2.php",
            type: 'GET',
            dataType: 'json', // will automatically convert array to JavaScript
            success: function(array) {
                var data=array;
                
                //LU
                $('#LU').text(data['lu']);
                
                
                //Dynamic Fields
                $('.dynamic').each(function(){
                	var element=$(this);
                	var canal = (typeof element.attr('canal') === 'undefined') ? element.closest('div').attr('canal') : element.attr('canal');
                	var tipo=element.attr('tipo');
                	var date=element.attr('date');
                	var op=element.attr('op');
                	var compare=element.attr('compare');
                	
                	try{
	                	element.attr('valor',getVal(data,canal,tipo,date,op,compare,'valor'));
	                	element.text(getVal(data,canal,tipo,date,op,compare));
	                }
	                catch(err){
	                	
	                }	
                	
                	//Format Fields
                	if(element.hasClass('var')){
                		element.removeClass('upvar');
                		element.removeClass('downvar');
                		if(element.attr('valor')>=10){
                			element.addClass('upvar');
                		}else if(element.attr('valor')<=-10){
                			element.addClass('downvar');
                		}
                	}
                });
                
                
                
                
                
           }
            
        });
    }

    $('#zoom').click(function(){
        if($(this).attr('status')==0){
            $('.header, .bloque, .bloque_short').addClass('zoomout');
            $('body').css('zoom','0.3');
            $(this).attr('status','1');
        }else{
            $('.header, .bloque, .bloque_short').removeClass('zoomout');
            $('body').css('zoom','1');
            $(this).attr('status','0');
        }

    })
});
</script>

<div class='header'>
KPIS Venta<br>
<aval id='LU'></aval>
</div>

<div class='bloque_short'>
    <div class='title ppdv'>PDV CO</div>
    <div class='container cppdv' canal='PDVCO'>
		<p>$<aval class='dynamic' tipo='monto' date='Td' op='total' compare='0'></aval><br>
            <a>
            	<!--(Venta: $<aval class='dynamic' tipo='venta' date='Td' op='total' compare='0'></aval> || Xld: $<aval class='dynamic downvar' tipo='xld' date='Td' op='total' compare='0'></aval>)<br>-->
            	Locs: <aval class='dynamic' tipo='loc' date='Td' op='total' compare='0'></aval> ( Y: <aval class='dynamic' tipo='loc' date='Y' op='total' compare='0'></aval> || LW: <aval class='dynamic' tipo='loc' date='LW' op='total' compare='0'></aval> )<br>
                Avg Tkt: $<aval class='dynamic' tipo='monto' date='Td' op='av' compare='0'></aval><br>
                Monto LW: $<aval class='dynamic' tipo='monto' date='LW' op='total' compare='0'></aval> | VarMonto LW: <aval class='dynamic var' tipo='monto' date='Td' op='var' compare='LW'></aval>%<br>
                Monto Yd: $<aval class='dynamic' tipo='monto' date='Y' op='total' compare='0'></aval> |  VarMonto Yd: <aval class='dynamic var' tipo='monto' date='Td' op='var' compare='Y'></aval>%
            </a>
        </p>
    </div>
</div>
