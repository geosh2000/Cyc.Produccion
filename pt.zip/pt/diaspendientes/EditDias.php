<?
include("DBAsesores.php");
include("../DBDiasPendientes.php");

$EditId=$_GET['id'];

echo $EditId;

?>