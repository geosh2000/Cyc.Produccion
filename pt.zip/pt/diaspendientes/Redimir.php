<?
$RedimMotif=$_GET['motif'];
$RedimId=$_GET['id'];
$RedimDias=$_GET['dias'];

include("../connectDB");

$RedimStatus="Testing Motivo: ".$RedimMotif." ID: ".$RedimId." Dias: ".$RedimDias;



?>
