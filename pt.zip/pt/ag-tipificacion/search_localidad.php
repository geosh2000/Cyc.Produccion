<?php
    include('../connectDB.php');

    //get search term
    $searchTerm = $_GET['term'];

    //get matched data from skills table
    $query = "SELECT DISTINCT localidad_agencia FROM ag_tipificacion WHERE localidad_agencia LIKE '%$searchTerm%' ORDER BY localidad_agencia ASC";
    if($result=$connectdb->query($query)){
    	while ($fila=$result->fetch_Assoc()) {
        	$data[] = $fila['localidad_agencia'];
		}
    }

    //return json data
    echo json_encode($data);
?>