<?php
session_start();
$this_page=$_SERVER['PHP_SELF'];
$iddiv=0;

if($_SESSION['login']!='1'){echo "status- DISC -status msg- Tu sesion ha expirado. Por favor da click en el menu para volver a loguearte. -msg"; exit;}

include("../connectDB.php");
header("Content-Type: text/html;charset=utf-8");

//Variables

function createPost($name){
    global $data;
    if($_POST[$name]==''){
        $data[$name]='NULL';
    }else{
        $data[$name]="'".utf8_decode($_POST[$name])."'";
    }
}

createPost('asesor');
createPost('agencia');
createPost('localidad');
createPost('canal');
createPost('motivo');
createPost('tipo');
createPost('soporte');
createPost('localizador');
createPost('nombre');

//Query

$query="INSERT INTO ag_tipificacion (canal,motivo,tipo,soporte,nombre_agencia,localidad_agencia,localizador, asesor,nombre_cliente) VALUES (".$data['canal'].",".$data['motivo'].",".$data['tipo'].",".$data['soporte'].",".$data['agencia'].",".$data['localidad'].",".$data['localizador'].",".$data['asesor'].",".$data['nombre'].")";
mysql_query($query);

if(mysql_errno()){
    echo "status- ERROR -status msg- Error al Guardar Registro ".mysql_error()." -msg";
}else{
    echo "status- OK -status msg- Registro Exitoso -msg";
}



?>