<?
session_start();
$this_page=$_SERVER['PHP_SELF'];
if($_SESSION['login']!='1'){ include("../common/login.php"); exit;}
$credential="schedules_upload";
$menu_programaciones="class='active'";
include("../common/scripts.php");
//echo session_id()."<br>";
include("../common/menu.php");
?>
<link rel="stylesheet" href="/js/periodpicker/build/jquery.periodpicker.min.css">
<script src="/js/periodpicker/build/jquery.periodpicker.full.min.js"></script>
<script>

$(function() {
    $('#inicio').periodpicker({
		end: '#fin',
		lang: 'en',
		animation: true
	});
});
</script>

<table class='t2' style='width:600px; margin:auto'><form action="vol_edit.php" method="post" enctype="multipart/form-data">
	<tr class='title'>
		<th colspan=10>Editor de Volumenes (Forecast)</th>
	</tr>
	<tr class='title'>
		<td style='width:33%'>Periodo</td>
		<td style='width:33%'>Programa</td>
		<td class='total' rowspan=2><input type="submit" value="Consultar" name="submit"></td>
	</tr>
	<tr class='pair'>
		<td><input type='text' name='start' id='inicio' required><input type='text' name='end' id='fin' required></td>
		<td class='pair'><select name="skill" required><option value=''>Selecciona...</option><?php  $query="SELECT * FROM PCRCs WHERE forecast=1 ORDER BY Departamento";
		 														$result=mysql_query($query);
																$num=mysql_numrows($result);
																for($i=0;$i<$num;$i++){
																	echo "<option value='".mysql_result($result, $i, 'id')."'>".mysql_result($result, $i, 'Departamento')."</option>";
																} ?></select></td>
		
	</tr>
	
</form></table>

</body>

</html>
