<?php
session_start();
$this_page=$_SERVER['PHP_SELF'];
$iddiv=0;

if($_SESSION['login']!='1'){ include("../common/login.php"); exit;}
$credential="asesor_formularios_bo";
$menu_asesores="class='active'";

?>

<?php
include("../connectDB.php");
header("Content-Type: text/html;charset=utf-8");
//GET variables
$sel_actividad=$_POST['actividad'];
if(isset($_POST['seguimiento'])){$sel_seguimiento="'".$_POST['seguimiento']."'";}else{$sel_seguimiento="NULL";}
if($_POST['em']!=""){$sel_caso="'".$_POST['em']."'";}else{$sel_caso="NULL";}
if($_POST['rs']!=""){$sel_resol="'".$_POST['rs']."'";}else{$sel_resol="NULL";}
if($_POST['redes_sociales']!=""){$sel_redes="'".$_POST['redes_sociales']."'";}else{$sel_redes="NULL";}
if($_POST['transportadora']!=""){$sel_transpo="'".$_POST['transportadora']."'";}else{$sel_transpo="NULL";}
if($_POST['fecha_asignacion']!=""){$sel_fecha="'".date('Y-m-d',strtotime($_POST['fecha_asignacion']))."'";}else{$sel_fecha="NULL";}
$sel_hora=$_POST['hr_asignacion'];
$sel_minuto=$_POST['min_asignacion'];
$hora=str_pad((int) $sel_hora,2,"0",STR_PAD_LEFT).":"
          .str_pad((int) $sel_minuto,2,"0",STR_PAD_LEFT).":00";

if($_POST['hr_asignacion']!=""){$sel_hora="'".date('H:i:s',strtotime($hora))."'";}else{$sel_hora="NULL";}
$sel_user=$_SESSION['id'];


//List Actividades
$query="SELECT * FROM bo_actividades WHERE area=3 ORDER BY actividad";
$result=mysql_query($query);
$num=mysql_numrows($result);
$i=0;
while($i<$num){
    $act_id[$i]=mysql_result($result,$i,'bo_act_id');
    $actividad[$i]=mysql_result($result,$i,'actividad');
$i++;
}

//List Seguimientos
$query="SELECT * FROM bo_seguimiento WHERE area=3 ORDER BY actividad, seguimiento";
$result=mysql_query($query);
$num=mysql_numrows($result);
$i=0;
while($i<$num){
    $seg_id[$i]=mysql_result($result,$i,'bo_seguimiento_id');
    $seguimiento[$i]=mysql_result($result,$i,'seguimiento');
    $seg_act[$i]=mysql_result($result,$i,'actividad');
$i++;
}

//List Transportadoras
$query="SELECT * FROM bo_transportadoras ORDER BY transportadora";
$result=mysql_query($query);
$num=mysql_numrows($result);
$i=0;
while($i<$num){
    $trans_id[$i]=mysql_result($result,$i,'bo_transpo_id');
    $transportadora[$i]=mysql_result($result,$i,'transportadora');
$i++;
}

//List Redes Sociales
$query="SELECT * FROM bo_redes_sociales ORDER BY tipo_seguimiento";
$result=mysql_query($query);
$num=mysql_numrows($result);
$i=0;
while($i<$num){
    $red_id[$i]=mysql_result($result,$i,'bo_redes_id');
    $redes[$i]=mysql_result($result,$i,'tipo_seguimiento');
$i++;
}


include("../common/scripts.php");

?>

<script>
$(function() {
    tips = $( ".validateTips" );
    $( "#picker" ).datepicker({
        altField: "#fecha_asignacion"
    });
    $( "#tabSeg1" ).hide();
    $( "#tabEM1" ).hide();
    $( "#tabAsig1" ).hide();
    $( "#tabAsig2" ).hide();
    $( "#tabRs1" ).hide();
    $( "#tabTrans1" ).hide();
    $( "#tabRed1" ).hide();

      function updateTips( t ) {
      if(t==""){
            tips
            .text( t )
            .removeClass( "ui-state-highlight");
        } else{
      tips
        .text( t )
        .addClass( "ui-state-highlight" );
      setTimeout(function() {
        tips.removeClass( "ui-state-highlight", 1500 );
      }, 500 );}
    }

    function checkLength( o, n, min, max ) {
      if ( o.val().length > max || o.val().length < min ) {
        o.addClass( "ui-state-error" );
        updateTips( "Length of " + n + " must be between " +
          min + " and " + max + "." );
        return false;
      } else {
          updateTips( "" );
          o.removeClass( "ui-state-error" );

          return true;
      }
    }

    function checkRegexp( o, regexp, n ) {
      if ( !( regexp.test( o.val() ) ) ) {
        o.addClass( "ui-state-error" );
        updateTips( n );
        return false;
      } else {
        o.removeClass( "ui-state-error" );

        updateTips("");
        return true;
      }
    }

    function hideall(){
        $( "#tabSeg1" ).hide();
        $( "#tabEM1" ).hide();
        $( "#tabAsig1" ).hide();
        $( "#tabAsig2" ).hide();
        $( "#tabRs1" ).hide();
        $( "#tabTrans1" ).hide();
        $( "#tabRed1" ).hide();
        $( "#seguimiento" ).attr('required',false);
        $( "#em" ).attr('required',false);
        $( "#fecha_asignacion" ).attr('required',false);
        $( "#hr_asignacion" ).attr('required',false);
        $( "#min_asignacion" ).attr('required',false);
        $( "#rs" ).attr('required',false);
        $( "#transportadora" ).attr('required',false);
        $( "#redes_sociales" ).attr('required',false);
        document.getElementById('seguimiento').value="";
        document.getElementById('fecha_asignacion').value="";
        document.getElementById('hr_asignacion').value="";
        document.getElementById('min_asignacion').value="";
        document.getElementById('em').value="";
        document.getElementById('redes_sociales').value="";
        document.getElementById('transportadora').value="";

    }

    function activate(Tabid, id, required){
        $("#"+Tabid+"1").show();
        $("#"+Tabid+"2").show();
        $("#"+Tabid+"3").show();
        if(required==1){
            $( "#"+id ).attr('required',true);
            if(Tabid=='TabAsign'){
                $( "#fecha_asignacion" ).attr('required',true);
                $( "#hr_asignacion" ).attr('required',true);
                $( "#min_asignacion" ).attr('required',true);
            }
        }


    }

    function deactivate(Tabid, id){
        $("#"+Tabid+"1").hide();
        $("#"+Tabid+"2").hide();
        $("#"+Tabid+"3").hide();
        $( "#"+id ).attr('required',false);
        if(Tabid=='TabAsign'){
            $( "#fecha_asignacion" ).attr('required',false);
            $( "#hr_asignacion" ).attr('required',false);
            $( "#min_asignacion" ).attr('required',false);
        }else{
            document.getElementById(id).value="";
        }

    }

    $('#actividad').change(function(){
        activate('tabEM','em',1);
        activate('tabAsig','fecha_asignacion',1);
    });

    $('#seguimiento').change(function(){
        var sel_id = $(this).val();
        if(sel_id!=''){
            activate('tabEM','em',1);
            if(sel_id!='14' && sel_id!='15' && sel_id!='16'){
                activate('tabAsig','fecha_asignacion',1);
                if(sel_id=='7'){
                    activate('tabRs','rs_si',1);
                }else{
                    deactivate('tabRs','rs_si');
                }
                if(sel_id=='8'){
                    activate('tabTrans','transportadora',1);
                }else{
                    deactivate('tabTrans','transportadora');
                }
                if(sel_id=='12'){
                    activate('tabRed','redes_sociales',1);
                }else{
                    deactivate('tabRed','redes_sociales');
                }
            }else{
                deactivate('tabAsig','fecha_asignacion');
            }
        }else{
            deactivate('tabEM','em');
        }


    });

    function submitForm(){
        var submit_em=$('#em').attr('required');
        var submit_seg=$('#seguimiento').attr('required');

        var submit_fa=$('#fecha_asignacion').attr('required');
        var submit_ha=$('#hr_asignacion').attr('required');
        var submit_ma=$('#min_asignacion').attr('required');
        var field_em=$('#em');
        var field_act=$('#actividad');
        var field_seg=$('#seguimiento');
        var field_fa=$('#fecha_asignacion');
        var field_ha=$('#hr_asignacion');
        var field_ma=$('#min_asignacion');
        var field_val=true;
        if(submit_em=='required' || field_em.val()!=""){
            field_val= field_val && checkLength( field_em, "EM", 6, 7 );
            field_val= field_val && checkRegexp( field_em, /[0-9][0-9][0-9][0-9][0-9][0-9]/, "El formato solicitado para EM acepta solo numeros (0 al 9)" );
        }
        if(submit_fa=='required'){
            field_val= field_val && checkLength( field_fa, "Fecha", 6, 11 );
            field_val= field_val && checkLength( field_ha, "Hora", 1, 2 );
            field_val= field_val && checkLength( field_ma, "Minutos", 1, 2 );
        }
        if(field_act.val()==""){
            field_val=false;
             $('#actividad').addClass( "ui-state-error" );
             updateTips("An option from \"Actividad\" must be selected" );
        }else{
            $('#actividad').removeClass( "ui-state-error" );
             updateTips("" )
        }
        if(submit_seg=='required' && field_seg.val()==""){
            field_val=false;
             $('#seguimiento').addClass( "ui-state-error" );
             updateTips("An option from \"Seguimiento\" must be selected" );
        }else{
            $('#seguimiento').removeClass( "ui-state-error" );
             updateTips("" );
        }

        var form_conf=$('#mejora');
        if(field_val){
            form_conf.submit();
        }






    }

    $('#enviar').click(function(){
       submitForm();
    });

  });
</script>

<?php
include("../common/menu.php");

//Query
if(isset($_POST['actividad'])){
    $query="INSERT INTO bo_mejora_continua
    (actividad, tipo_seguimiento, em, fecha_recepcion, hora_recepcion, resolucion_satisfactoria,seguimiento_redes,transportadora,user)
    VALUES
    ($sel_actividad,$sel_seguimiento,$sel_caso,$sel_fecha,$sel_hora,$sel_resol,$sel_redes,$sel_transpo,'$sel_user')";
    mysql_query($query);
    if(mysql_errno()){
        echo "<table width='100%' class='t2'>
    <tr class='rojo'>
        <td colspan=100>MySQL error ".mysql_errno().": "
			         .mysql_error()."\n<br>When executing <br>\n$query\n<br><br></td>
    </tr>
</table>
<br>";
                     $err_count++;

			}else{echo "<table width='100%' class='t2' id='AvisoOk'>
    <tr class='green'>
        <td colspan=100>Registro Exitoso</td>
    </tr>
</table>
<br>";}
}
?>
<table width='100%' class='t2'>
    <tr class='title'>
        <td colspan=100>Formulario Mejora Continua</td>
    </tr>
</table>
<br>
<div style='width:40%; margin: auto'>
<p class="validateTips">Fill the required Fields.</p>
</div>

<table style='width: 40%; margin: auto' class='t2'>
<form method='POST' action='<?php echo $_SERVER['PHP_SELF']; ?>' name="mejora" id="mejora">
<tr class='title'>
    <th colspan=2>Informacion</th>
</tr>
    <tr class='title' id='tabAct1'>
        <th>Actividad</th>
        <td  class='pair'><select name="actividad" id="actividad" required>
        <option value="">Selecciona...</option>
        <?php
            foreach($actividad as $key => $act){
                echo "\t<option value='$act_id[$key]' $selected>$act</option>\n";
            }
            unset($key, $act);
        ?></select></td>
    </tr>
    <tr class='title'  id='tabSeg1'>
        <th>Tipo de seguimiento / llamada</th>
        <td class='pair'><select name="seguimiento" id="seguimiento"><option value="" title='100'>Selecciona...</option><?php
            foreach($seguimiento as $key => $seg){
                if($key==0){echo "<option value='' title='$seg_act[$key]'>Selecciona...</option>"; $tmp_act=$seg_act[$key];}
                if($tmp_act!=$seg_act[$key]){echo "<option value='' title='$seg_act[$key]'>Selecciona...</option>"; $tmp_act=$seg_act[$key];}
                echo "<option value='$seg_id[$key]' title='$seg_act[$key]' $selected>$seg</option>";
                $tmp_act=$seg_act[$key];
            }
            unset($key, $seg);
        ?></select></td>
    </tr>
    <tr class='title'  id='tabEM1'>
        <th>Caso EM (######)</th>
        <td class='pair'><input type="text" name='em' id='em' value=''></td>
    </tr>
    <tr class='title' id='tabAsig1'>
        <th>Fecha Asignacion</th>
        <td class='pair'><div align="center"  id='picker'></div><input type='text' name='fecha_asignacion' id='fecha_asignacion' value='' readonly></td>
    </tr>
    <tr class='title' id='tabAsig2'>
        <th>Hora Asignacion (24 hrs)</th>
        <td class='pair'><input type='number' name='hr_asignacion' id='hr_asignacion' value='' min=0 max=23 maxlength=2 size=2 step=1> : <input type='number' name='min_asignacion' id='min_asignacion' value='' min=0 max=59 maxlength=2 size=2 step=1> hrs.</td>
    </tr>
    <tr class='title' id='tabRs1'>
        <th>Resolucion Satisfactoria</th>
        <td class='pair'>Si: <input type="radio" name='rs' id='rs_si' value='1'>No: <input type="radio" name='fcc' id='rs_no' value='0'></td>
    </tr>
    <tr class='title' id='tabTrans1'>
        <th>Transportadora</th>
        <td  class='pair'><select name="transportadora" id="transportadora" required>
        <option value="">Selecciona...</option>
        <?php
            foreach($transportadora as $key => $trans){
                echo "\t<option value='$trans_id[$key]'>$trans</option>\n";
            }
            unset($key, $trans);
        ?></select></td>
    </tr>
    <tr class='title' id='tabRed1'>
        <th>Redes Sociales</th>
        <td  class='pair'><select name="redes_sociales" id="redes_sociales" required>
        <option value="">Selecciona...</option>
        <?php
            foreach($redes as $key => $red){
                echo "\t<option value='$red_id[$key]'>$red</option>\n";
            }
            unset($key, $red);
        ?></select></td>
    </tr>
    <tr class='total'>
        <td colspan=2 ><input type="button" name='enviar' id='enviar' value='Enviar' /></td>
    </tr>
</form>
</table>
