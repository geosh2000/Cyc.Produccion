<?php
ini_set('session.gc_maxlifetime', 28800);
session_start();
header('Content-Type: text/html; charset=utf-8');


$this_page=$_SERVER['PHP_SELF'];
$iddiv=0;

if($_SESSION['login']!='1'){ include("../common/login.php"); exit;}
$credential="asesor_tipificacion_us";

date_default_timezone_set('America/Bogota');

include("../connectDB.php");
include("../common/scripts.php");
include("../common/menu.php");


$asesor=$_SESSION['asesor_id'];

?>

<script>

$(function(){

    $("#login").hide();

    $( "#f_Destino" ).autocomplete({
       source: 'search_destino.php'
    });
    
    function loginPop(variable) {
        if(variable=='ok'){
          var page="/common/login.php?modal=on";
          var $dialog = $('#login')
          .html('<iframe style="border: 0px; " src="' + page + '" width="100%" height="100%"></iframe>')
          .dialog({
            title: "Login",
            autoOpen: false,
            dialogClass: 'dialog_fixed,ui-widget-header',
            modal: true,
            height: 500,
            minWidth: 600,
            minHeight: 400,
            draggable:true,
            /*close: function () { $(this).remove(); },*/
            buttons: { "Ok": function () {         $(this).dialog("close"); } }
          });
          $dialog.dialog('open');
        }
    }
    
    function sendRequest(variables){

    var urlok='query.php';
    var xmlhttp;
        var text;
        if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
        } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }

        xmlhttp.onreadystatechange=function(){
            if (xmlhttp.readyState==4 && xmlhttp.status==200){
                text= xmlhttp.responseText;
                var status = text.match("status- (.*) -status");
                 var startlogin='no';
                var notif_msg = text.match("msg- (.*) -msg");
                if(status[1]=='OK'){
                    var notif_regs = text.match("regs- (.*) -regs");
                    $('#regs').text(notif_regs[1]);
                    tipo_noti='success';
                    $('.input').val('');
                    start_fields();
                }else{
                    if(status[1]=='DISC'){
                        tipo_noti='error';
                        startlogin='ok';
                    }else{
                        tipo_noti='error';
                    }
                }
                new noty({
                    text: notif_msg[1],
                    type: tipo_noti,
                    timeout: 10000,
                    animation: {
                        open: {height: 'toggle'}, // jQuery animate function property object
                        close: {height: 'toggle'}, // jQuery animate function property object
                        easing: 'swing', // easing
                        speed: 500 // opening & closing animation speed
                    },
                    callback: {
                        onShow: function(){
                            loginPop(startlogin);
                        }
                        }
                });
                $('#submit_form').prop('disabled',false);

            }
        }
        xmlhttp.open("POST",urlok,true);
        xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xmlhttp.send(variables);

    }

    flag=true;

    function start_fields(){
        $('#contain-Objecion, #contain-NewLoc').hide().attr('req',0);
        $('.offered').prop('checked',false);
		$('#contain-base, #contain-Nombre, #contain-Telefono, #contain-Destino, #contain-Original, #contain-Motivo, #contain-Acompanantes, #contain-Resolucion').attr('req',1);
	}

    start_fields();

    function validate(){
        //Base
        if($('#contain-base').attr('req')==1 && $('#f_base').val()==''){
            flag_base=false;
            $('#f_base').addClass('error');
        }else{
            flag_base=true;
            $('#f_base').removeClass('error');
        }
        
        //Nombre
        if($('#contain-Nombre').attr('req')==1 && $('#f_Nombre').val()==''){
            flag_Nombre=false;
            $('#f_Nombre').addClass('error');
        }else{
            flag_Nombre=true;
            $('#f_Nombre').removeClass('error');
        }
        
        //Telefono
        if($('#contain-Telefono').attr('req')==1 && $('#f_Telefono').val()==''){
            flag_Telefono=false;
            $('#f_Telefono').addClass('error');
        }else{
            flag_Telefono=true;
            $('#f_Telefono').removeClass('error');
        }
        
        //Destino
        if($('#contain-Destino').attr('req')==1 && $('#f_Destino').val()==''){
            flag_Destino=false;
            $('#f_Destino').addClass('error');
        }else{
            flag_Destino=true;
            $('#f_Destino').removeClass('error');
        }
        
        //Original
        if($('#contain-Original').attr('req')==1 && $('#f_Original').val()==''){
            flag_Original=false;
            $('#f_Original').addClass('error');
        }else{
            flag_Original=true;
            $('#f_Original').removeClass('error');
        }
        
        //Motivo
        if($('#contain-Motivo').attr('req')==1 && $('#f_Motivo').val()==''){
            flag_Motivo=false;
            $('#f_Motivo').addClass('error');
        }else{
            flag_Motivo=true;
            $('#f_Motivo').removeClass('error');
        }
        
        //Acompanantes
        if($('#contain-Acompanantes').attr('req')==1 && $('#f_Acompanantes').val()==''){
            flag_Acompanantes=false;
            $('#f_Acompanantes').addClass('error');
        }else{
            flag_Acompanantes=true;
            $('#f_Acompanantes').removeClass('error');
        }
        
        //Resolucion
        if($('#contain-Resolucion').attr('req')==1 && $('#f_Resolucion').val()==''){
            flag_Resolucion=false;
            $('#f_Resolucion').addClass('error');
        }else{
            flag_Resolucion=true;
            $('#f_Resolucion').removeClass('error');
        }
        
        //NewLoc
        if($('#contain-NewLoc').attr('req')==1 && $('#f_NewLoc').val()==''){
            flag_NewLoc=false;
            $('#f_NewLoc').addClass('error');
        }else{
            flag_NewLoc=true;
            $('#f_NewLoc').removeClass('error');
        }
        
        //Objecion
        if($('#contain-Objecion').attr('req')==1 && $('#f_Objecion').val()==''){
            flag_Objecion=false;
            $('#f_Objecion').addClass('error');
        }else{
            flag_Objecion=true;
            $('#f_Objecion').removeClass('error');
        }

        

        if(flag_base && flag_Nombre && flag_Telefono && flag_Destino && flag_Original && flag_Motivo && flag_Acompanantes && flag_Resolucion && flag_NewLoc && flag_Objecion ){flag=true;}else{flag=false; $('#submit_form').prop('disabled',false);}

    }

    //Resolucion
    $('#f_Resolucion').change(function(){
    	$('#contain-NewLoc, #contain-Objecion').fadeOut('200').attr('req',0);
    	$('#f_NewLoc, #f_Objecion').val('');
    	campo=($('option:selected', this).attr('activate'));
    	if(campo!=''){
    		$('#contain-'+campo).fadeIn('200').attr('req',1);
    	}   
    });

    //BUTTON Submit
    $('#submit_form').click(function(){
    	$(this).prop('disabled',true);
        validate();
        if(flag){
            var variables="asesor=<?php echo $asesor; ?>&base=" + $('#f_base').val() + 
            "&nombre=" + $('#f_Nombre').val() + 
            "&telefono=" + $('#f_Telefono').val() + 
            "&localizador=" + $('#f_Localizador').val() + 
            "&destino=" + $('#f_Destino').val() + 
            "&original=" + $('#f_Original').val() +
            "&motivo=" + $('#f_Motivo').val() +
            "&acompanantes=" + $('#f_Acompanantes').val() +
            "&resolucion=" + $('#f_Resolucion').val() +
            "&newloc=" + $('#f_NewLoc').val() + 
            "&auto=" + $('#f_Ofertado_Auto').is(":checked") + 
            "&certificado=" + $('#f_Ofertado_Certificado').is(":checked") + 
            "&tour=" + $('#f_Ofertado_Tour').is(":checked") + 
            "&traslado=" + $('#f_Ofertado_Traslado').is(":checked") + 
            "&objecion=" + $('#f_Objecion').val();
            //alert(variables);
            sendRequest(variables);
        }
    })

	//Change to UPPERCASE
    $('#f_destino, #f_Nombre').keyup(function(){
        var name=$(this).val();
        var newname=name.toUpperCase();
        $(this).val(newname);
    });

});

</script>

<style>
.formulario{
    width: 1200px;
    height: 100%;
    margin: auto;
    overflow: auto;
    text-align: center
}

.titulo{
    width: 800px;
    height: 65px;
    font-size: 24px;
    font-weight: bold;
    text-align: center;
    margin: auto;
    margin-top: -19px;
    border-radius: 15px;
    background: #008CBA
}

.campo{
    width: auto;
    height: 80px;
    margin: 10;
    border-radius: 15px;
    display: inline-block;
}

.campo .name{
    float: left;
    height: 100%;
    width: 170px;
    background: #008CBA;
    border-radius: 15px 0 0 15px;
    color: white;
    font-size: 20px;
    font-weight: bold;
    text-align: center;
}

.campo .name p{
    padding-top:12px;
}

.campo .opcion{
    float: left;
    height: 100%;
    width: 245px;
    background: #E7F5FE;
    border-radius: 0 15px 15px 0;
    color: black;
    font-size: 20px;
    text-align: center;
}

.campo .opcion .seleccion{
    padding-top:5px;
}

.seleccion select, .seleccion input{
    width: 200px;
}

.error{
    background: #FFE8E0;
}



</style>
<?php

$query="SELECT COUNT(id) as Registros FROM us_servicios_adicionales WHERE CAST(Last_Update as DATE)=CURDATE() AND asesor=$asesor";
$result=mysql_query($query);
$regs=mysql_result($result,0,'Registros');
?>
<div style='width:90%; margin: auto;'>
<div class='formulario'>
    <div class='titulo'>
        <p style='padding-top: 13px; color: white;'>Tipificación de Llamadas - Upsell</p>
        <p style='padding-top: 0px; color: white; font-size:16px; margin-top: -14px; font-weight: normal;'>Registros: <regs id='regs'><?php echo $regs; ?></regs></p>
    </div>
    <div id='contain-base' class='campo'>
        <div class='name'>
            <p>Base</p>
        </div>
        <div class='opcion'>
            <p class='seleccion'><select id='f_base' class='input'><option value=''>Selecciona...</option>
            <?php
                $query="SELECT * FROM us_bases WHERE active=1 ORDER BY Base";
                $result=mysql_query($query);
                $num=mysql_numrows($result);
                $i=0;
                while($i<$num){
                    echo "<option value='".mysql_result($result,$i,'id')."'>".utf8_encode(mysql_result($result,$i,'Base'))."</option>";
                $i++;
                }
            ?></select>*</p>
        </div>
    </div>
    <div id='contain-Nombre' class='campo'>
        <div class='name'>
            <p>Nombre</p>
        </div>
        <div class='opcion'>
            <p class='seleccion'><input type='text' id='f_Nombre' class='input' value=''></p>
        </div>
    </div>
    <div id='contain-Telefono' class='campo'>
        <div class='name'>
            <p>Telefono</p>
        </div>
        <div class='opcion'>
            <p class='seleccion'><input type='text' id='f_Telefono' class='input' value=''></p>
        </div>
    </div>
    <div id='contain-Localizador' class='campo'>
        <div class='name'>
            <p>Localizador</p>
        </div>
        <div class='opcion'>
            <p class='seleccion'><input type='text' id='f_Localizador' class='input' value=''></p>
        </div>
    </div>
    <div id='contain-Destino' class='campo'>
        <div class='name'>
            <p>Destino</p>
        </div>
        <div class='opcion'>
            <p class='seleccion'><input type='text' id='f_Destino' class='input' value=''></p>
        </div>
    </div>
    <div id='contain-Original' class='campo'>
        <div class='name'>
            <p>Servicio Original</p>
        </div>
        <div class='opcion'>
            <p class='seleccion'><select id='f_Original' class='input'><option value=''>Selecciona...</option>
            <?php
                $query="SELECT * FROM us_servicios WHERE active=1 ORDER BY Servicio";
                $result=mysql_query($query);
                $num=mysql_numrows($result);
                $i=0;
                while($i<$num){
                    echo "<option value='".mysql_result($result,$i,'id')."'>".mysql_result($result,$i,'Servicio')."</option>";
                $i++;
                }
            ?></select>*</p>
        </div>
    </div>
    <div id='contain-Motivo' class='campo'>
        <div class='name'>
            <p>Motivo del Viaje</p>
        </div>
        <div class='opcion'>
            <p class='seleccion'><select id='f_Motivo' class='input'><option value=''>Selecciona...</option>
            <?php
                $query="SELECT * FROM us_motivo_viaje WHERE active=1 ORDER BY Motivo";
                $result=mysql_query($query);
                $num=mysql_numrows($result);
                $i=0;
                while($i<$num){
                    echo "<option value='".mysql_result($result,$i,'id')."'>".mysql_result($result,$i,'Motivo')."</option>";
                $i++;
                }
            ?></select>*</p>
        </div>
    </div>
    <div id='contain-Acompanantes' class='campo'>
        <div class='name'>
            <p>Acompañantes</p>
        </div>
        <div class='opcion'>
            <p class='seleccion'><select id='f_Acompanantes' class='input'><option value=''>Selecciona...</option><?php
                $query="SELECT * FROM us_acompanantes ORDER BY Acompanantes";
                $result=mysql_query($query);
                $num=mysql_numrows($result);
                $i=0;
                while($i<$num){
                    echo "<option value='".mysql_result($result,$i,'id')."'>".mysql_result($result,$i,'Acompanantes')."</option>";
                $i++;
                }
            ?></select>*</p>
        </div>
    </div>
    <div id='contain-Ofertado' class='campo'>
        <div class='name'>
            <p>Servicio Ofertado</p>
        </div>
        <div class='opcion' style='font-size: 17px; text-align: right; padding-right: 73px; width: 172px;'>
            Auto<input type='checkbox' id='f_Ofertado_Auto' class='offered'><br>
            Certificado<input type='checkbox' id='f_Ofertado_Certificado' class='offered'><br>
            Tour<input type='checkbox' id='f_Ofertado_Tour' class='offered'><br>
            Traslado<input type='checkbox' id='f_Ofertado_Traslado' class='offered'><br>
        </div>
    </div>
    <div id='contain-Resolucion' class='campo'>
        <div class='name'>
            <p>Resolucion</p>
        </div>
        <div class='opcion'>
            <p class='seleccion'><select id='f_Resolucion' class='input'><option value=''>Selecciona...</option><?php
                $query="SELECT * FROM us_resolucion WHERE active=1 ORDER BY Resolucion";
                $result=mysql_query($query);
                $num=mysql_numrows($result);
                $i=0;
                while($i<$num){
                    echo "<option activate='".mysql_result($result,$i,'opt_habilitar')."' value='".mysql_result($result,$i,'id')."'>".mysql_result($result,$i,'Resolucion')."</option>";
                $i++;
                }
            ?></select>*</p>
        </div>
    </div>
    <div id='contain-Objecion' class='campo'>
        <div class='name'>
            <p>Objecion</p>
        </div>
        <div class='opcion'>
            <p class='seleccion'><select id='f_Objecion' class='input'><option value=''>Selecciona...</option><?php
                $query="SELECT * FROM us_objecion WHERE active=1 ORDER BY Objecion";
                $result=mysql_query($query);
                $num=mysql_numrows($result);
                $i=0;
                while($i<$num){
                    echo "<option value='".mysql_result($result,$i,'id')."'>".utf8_encode(mysql_result($result,$i,'Objecion'))."</option>";
                $i++;
                }
            ?></select>*</p>
        </div>
    </div>
    <div id='contain-NewLoc' class='campo'>
        <div class='name'>
            <p>Localizador Nuevo</p>
        </div>
        <div class='opcion'>
            <p class='seleccion'><input type='text' id='f_NewLoc' class='input' value=''></p>
        </div>
    </div>
    <div id='contain-submit' style='text-align: center;'>
        <button class='button button_red_w' id='submit_form'>Guardar</button>
    </div>

</div>
<div id='errordiv'></div>
</div>

		