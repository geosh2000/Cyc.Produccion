<?php

session_start();
$this_page=$_SERVER['PHP_SELF'];
if($_SESSION['login']!='1'){ include("../common/login.php"); exit;}
date_default_timezone_set('America/Bogota');
$credential="schedules_change";
$menu_programacion="class='active'";

include("../connectDB.php");
include("../common/scripts.php");

$query="SELECT *
	FROM Ausentismos a, `Tipos Ausentismos`b, Asesores c, userDB d
	WHERE
		a.tipo_ausentismo=b.id AND
		a.asesor=c.id AND
		a.User=d.userid AND
		Activo=1 AND
		needs_moper=1 AND
		ISI=0  AND
        Inicio>='2016-03-15'
	ORDER BY
		Inicio";
$result=mysql_query($query);
$num=mysql_numrows($result);
$i=0;
while($i<$num){
    $data['id_Ausentismo'][$i]=mysql_result($result,$i,'ausent_id');
    $data['id_asesor'][$i]=mysql_result($result,$i,'asesor');
    $data['Nombre'][$i]=mysql_result($result,$i,'N Corto');
    $data['Tipo_ausentismo'][$i]=mysql_result($result,$i,'tipo_ausentismo');
    $data['Ausentismo'][$i]=mysql_result($result,$i,'Ausentismo');
    $data['Inicio'][$i]=mysql_result($result,$i,'Inicio');
    $data['Fin'][$i]=mysql_result($result,$i,'Fin');
    $data['Descansos'][$i]=mysql_result($result,$i,'Descansos');
    $data['Beneficios'][$i]=mysql_result($result,$i,'Beneficios');
    $data['Caso'][$i]=mysql_result($result,$i,'caso');
    $data['Comentarios'][$i]=mysql_result($result,$i,'Comments');
    $data['WFM'][$i]=mysql_result($result,$i,'username');
    $data['num_colaborador'][$i]=mysql_result($result,$i,'num_colaborador');

$i++;
}

include("../common/menu.php");
?>

<script>

$(document).ready(function()
    {
        $("#mopers").tablesorter();
    }
);

$(function(){



    var dialog, form,

      // From http://www.whatwg.org/specs/web-apps/current-work/multipage/states-of-the-type-attribute.html#e-mail-state-%28type=email%29
      id_field = $( "#a_id" ),
      moper_field = $( "#mopernew" ),
      allFields = $( [] ).add( id_field ).add( moper_field ),
      tips = $( ".validateTips" );

    function updateTips( t ) {
      tips
        .text( t )
        .addClass( "ui-state-highlight" );
      setTimeout(function() {
        tips.removeClass( "ui-state-highlight", 1500 );
      }, 500 );
    }



    function checkLength( o, n, min, max ) {
      if ( o.val().length > max || o.val().length < min ) {
        o.addClass( "ui-state-error" );
        updateTips( "Length of " + n + " must be between " +
          min + " and " + max + "." );
        return false;
      } else {
        return true;
      }
    }

    function checkRegexp( o, regexp, n ) {
      if ( !( regexp.test( o.val() ) ) ) {
        o.addClass( "ui-state-error" );
        updateTips( n );
        return false;
      } else {
        return true;
      }
    }

    function addUser() {
     var id=$("#a_id");
     var moper=$("#mopernew");
     var valid = true;
     var tipo_noti;
     var target="tr"+id.val();

     allFields.removeClass( "ui-state-error" );

    if ( valid ) {

     var ok_url="../json/add_moper.php?id="+id.val()+"&moper="+moper.val();


        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                var text = xmlhttp.responseText;
                var text_noti = text.match("tipo- (.*) -tipo");
                var notif_msg = text.match("msg- (.*) -msg");
                if(text_noti[1]=="Registro Exitoso"){

                    tipo_noti='success';
                    $('table#mopers tr#'+target).remove();
                }else{
                    tipo_noti='error';

                }
                new noty({
                    text: notif_msg[1],
                    type: tipo_noti,
                    timeout: 5000,
                    animation: {
                        open: {height: 'toggle'}, // jQuery animate function property object
                        close: {height: 'toggle'}, // jQuery animate function property object
                        easing: 'swing', // easing
                        speed: 500 // opening & closing animation speed
                    }
                });
            }
        }
        xmlhttp.open("GET",ok_url,true);
        xmlhttp.send();


      dialog.dialog( "close" );

    }
      return valid;
    }

    dialog = $( "#dialog-form" ).dialog({
      autoOpen: false,
      height: 300,
      width: 550,
      modal: true,
      buttons: {
        "Cargar Moper": addUser,
        Cancel: function() {
          dialog.dialog( "close" );
        }
      },
      close: function() {
        form[ 0 ].reset();
        allFields.removeClass( "ui-state-error" );
      }
    });

    form = dialog.find( "form" ).on( "submit", function( event ) {
      event.preventDefault();
      addUser();
    });

    $('#<?php echo $data['id_Ausentismo'][0]; ?>, sh:gt(0):lt(5000)').button().on( "click", function() {
      var x=this.id;
      var f_id=document.getElementById('id_Ausentismo_'+x);
      var n_id=document.getElementById('a_id');
      n_id.value=f_id.innerText;

      dialog.dialog( "option", "position", { my: "left bottom", at: "left top", of: '#'+x } );
      dialog.dialog( "open" );
    });

});
</script>

<table style='width:80%; margin: auto' class='t2'>
    <tr class='title'>
        <th colspan=100>Moper Pendientes</th>
    </tr>
</table>
<table style='width:80%; margin: auto' class='t2' id='mopers'>
    <thead>
    <tr class='title'>
    <?php
    foreach($data as $key => $title){
         echo "<th>".str_replace("_"," ",$key)."</th>\n";
    }
    unset($key);

    ?>
        <th>Editar</th>

    </tr>
    </thead>
    <tbody>
    <?php
        foreach($data['id_Ausentismo'] as $key => $iden){
            if($key % 2 == 0){$class="class='pair'";}else{$class="class='odd'";}
            echo "<tr $class id='tr$iden'>\n";
            foreach($data as $key2 => $info){
                echo "<td id='".$key2."_$iden'>$info[$key]</td>\n";
            }
            unset($key2, $info);
            echo "<td><sh id='$iden'>Editar</sh></td>\n";
            echo "</tr>\n";
        }
    ?>
    </tbody>
</table>
<div id="dialog-form" title="Cambiar Moper">
 <p class="validateTips">Fill the required Fields.</p>

  <form>
    <fieldset>
        <table width='480px'>
            <tr>
                <td width='30%'><label for="a_id">ID</label></td>
                <td><input type="text" name="a_id" id="a_id" value="" class="text ui-widget-content ui-corner-all" readonly></td>
            </tr>
            <tr>
                <td width='30%'><label for="date">Moper Nuevo</label></td>
                <td><input type="text" name="mopernew" id="mopernew" value="" class="text ui-widget-content ui-corner-all"></td>

            </tr>
            </table>
      <!-- Allow form submission with keyboard without duplicating the dialog button -->
      <input type="submit" tabindex="-1" style="position:absolute; top:-1000px">
    </fieldset>
  </form>
</div>