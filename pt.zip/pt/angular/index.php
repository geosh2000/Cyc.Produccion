<?php


	echo '<title>AngularJS Installed</title><div style="background: #e9ffed; border: 1px solid #b0dab7; padding: 15px;" align="center" >
	<font size="5" color="#182e7a">AngularJS is installed successfully.</font><br /><br />
	<font size="4">AngularJS is a JavaScript, so doesn\'t have an index page.<br /><br />
	AngularJS HTML enhanced for web apps!

AngularJS is a structural framework for dynamic web apps. It lets you use HTML as your template language and lets you extend HTML\'s syntax to express your application\'s components clearly and succinctly. Out of the box, it eliminates much of the code you currently write through data binding and dependency injection. And it all happens in JavaScript within the browser, making it an ideal partner with any server technology. </font></div>';

?>